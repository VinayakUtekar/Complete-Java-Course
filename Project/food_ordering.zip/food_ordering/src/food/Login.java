package food;

public interface Login {
	void login();
	void singup();

}
