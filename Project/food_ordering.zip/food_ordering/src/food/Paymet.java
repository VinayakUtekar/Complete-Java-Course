package food;

public interface Paymet {
	
	void upiPaymet();

}
